/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication25;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Arrays;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.JButton;
import javax.swing.JFileChooser;  

/**
 *
 * @author Nick
 */
public class ITunes1 {
    
    static int counter;   // the number of users
    static Library[] users = new Library[10];  // alocates storage for 10 user libraries
    static Library currentUser;  // stores the current user
    static Songs[] copyArray;  // used to store a second copy of users library
    
    public void run() throws FileNotFoundException, IOException {
        
        Scanner sc = new Scanner(System.in);
        File f1 = new File("users.txt");
        String userName;
        boolean found = false;
        
        if(f1.exists()){
           Scanner us = new Scanner(f1);
           while(us.hasNextLine()){
               String name = us.next();
              users[counter] = new Library(name);
               counter++;               
           }
           System.out.println("Enter your username");
           userName = sc.next();
           for(int i = 0; i < counter; i++){
            if (userName.equals(users[i].userName)){
                found = true;
            }
          }
          if(found) {
              pickUser(userName);
              computerUploadAlbum(userName);
              printMainMenu();
          }
          else {
              addUser(userName);
              pickUser(userName);
              System.out.println("Choose a number.");
              System.out.println("1. Upload an album");
              System.out.println("2. exit");
              int choice = sc.nextInt();
              switch(choice){
                case 1:
                    System.out.println("Use file chooser to upload album");
                    uploadAlbum();
                    printMainMenu();
                    break;
                case 2:
                    break;
            }            
         }
        }
        else{
            printLoginMenu();
        }      
    }
    public void printLoginMenu() throws FileNotFoundException, IOException {
        
        Scanner sc = new Scanner(System.in);  //used to read input
        File f1 = new File("users.txt");  // stores all users
        String userName;  // stores user name input
        
        System.out.println("System has no users.");
        System.out.println("Enter your username");
        userName = sc.next();
        addUser(userName);
        pickUser(userName);
        System.out.println("Choose a number.");
        System.out.println("1. Upload an album");
        System.out.println("2. exit");
        int choice = sc.nextInt();
        switch(choice){
            case 1:
                System.out.println("Use file chooser to upload album");
                uploadAlbum();
                printMainMenu();
                break;
            case 2:
                break;
        }        
    }
public static void printMainMenu() throws FileNotFoundException, IOException{
        
     Scanner sc = new Scanner(System.in);  //used to read input
     boolean go = true;  // used to exit Itunes
     boolean found = false; // used to find user
        
     do{
        System.out.println("Choose a number.");
        System.out.println("1. Upload an album");
        System.out.println("2. Sort songs");
        System.out.println("3. Search for artist");
        System.out.println("4. Search for album");
        System.out.println("5. Search for title");
        System.out.println("6. exit and save.");
        System.out.println("7. switch user");
        int choiceTwo = sc.nextInt();
        switch(choiceTwo){
            case 1:
                System.out.println("Use file chooser to upload album");
                uploadAlbum();
                break;
            case 2:
                sortAlbum();
                printAlbum();
                break;
            case 3:
                System.out.print("Enter what artist you want to search for.");
                String artistName = sc.nextLine();
                artistName = sc.nextLine();
                artistSearchAndSort(artistName);
                break;
            case 4:
                System.out.print("Enter what album you want to search for.");
                String albumName = sc.next();
                displaySubAlbums(albumName);
                sc.nextLine();
                break;
            case 5:
                System.out.print("Enter what song or expression you want to search for.");
                String songName = sc.next();
                findASong(songName);
                sc.nextLine();
                break;
            case 6:
                saveAlbums();
                go = false;
                break;
            case 7:
                System.out.println("Enter your username");
                String userName = sc.next();
                for(int i = 0; i < counter; i++){
                  if (userName.equals(users[i].userName)){
                     found = true;
                  }
                }
                if(found) {
                  pickUser(userName);
                  computerUploadAlbum(userName);
                }
                else {
                   addUser(userName);
                   pickUser(userName);
                   System.out.println("Use file chooser to upload album");
                   uploadAlbum();
                }   
            }
   }while(go);  
}
    public static void displayUsers(){
       System.out.println("The users on the sytem are " );
       for(int i = 0; i < counter; i++ ){
            System.out.println(users[i].userName);
        }        
    }
    public static void addUser(String n){
        
        users[counter] = new Library(n);
        counter++;
    }
    
    public static void pickUser(String a){
        boolean found = false;
        for(int i = 0; i < counter; i++){
            if (a.equals(users[i].userName)){
                currentUser = users[i];
                found = true;
                break;
            }
        }
        if (found == false)
             System.out.println("This user is not found");
    }
    
    public static void uploadAlbum() throws FileNotFoundException{
        
        int numberOfSongs = 0; // stores number of songs uploaded
        String songName;  // sores the name of the song 
        String artist;  // stores the artist
        String albumName;  // stores the album name
        int trackNumber;  //stores the track number
        
        JButton open = new JButton();
        JFileChooser fc = new JFileChooser();
        fc.setCurrentDirectory(new java.io.File("./"));
        fc.setDialogTitle("Albums");
        fc.setFileSelectionMode(JFileChooser.FILES_ONLY);
        fc.showOpenDialog(open);
        System.out.println(fc.getSelectedFile().getName());
        File f = new File(fc.getSelectedFile().getAbsolutePath());
        Scanner sc = new Scanner(f);
       
        if(sc.hasNextLine()){
            numberOfSongs = sc.nextInt();
            currentUser.previousNumberOfSongs = currentUser.numberOfSongs; 
            currentUser.numberOfSongs = numberOfSongs + currentUser.numberOfSongs;
            sc.nextLine();
           
        }
        sc.useDelimiter("[,\r\n]");
        
        for(int i = currentUser.previousNumberOfSongs; i < currentUser.numberOfSongs; i++){
            if(sc.hasNextLine()){
            albumName = fc.getSelectedFile().getName();
            trackNumber = sc.nextInt();
            songName = sc.next();
            songName = songName.trim();
            artist = sc.next();
            artist = artist.trim();
            currentUser.album[i] = new Songs(trackNumber, songName, artist, albumName);
            }
        }
    }
    
    public static void printAlbum(){
        System.out.println("Songs");
        for(int i = 0; i < currentUser.numberOfSongs; i++){
            System.out.print(currentUser.album[i]);
        }
    }
   
    public static void sortAlbum(){
        Arrays.sort(currentUser.album, 0 , currentUser.numberOfSongs);
    }
    
    public static void artistSearchAndSort(String a){
        int numberOfArtist = 0;  // stores the index of the artist you are searching for
        int counter = 0;  // stores the number of artists songs
     
        for(int i = 0; i < currentUser.numberOfSongs;  i++){
            if(currentUser.album[i].getArtistName().equals(a)){
                numberOfArtist++;
            }
        }
            copyArray = new Songs[numberOfArtist];
            
           for(int i = 0; i < currentUser.numberOfSongs;  i++){
            if(currentUser.album[i].getArtistName().equals(a)){   
                copyArray[counter] = currentUser.album[i];
                counter++;
            }
           }
           System.out.println("Artists Songs");
            Arrays.sort(copyArray, 0 , counter);
             for(int i = 0; i < counter; i++){
                //System.out.println(copyArray[i].getSongName());
                System.out.println(copyArray[i]);
        }
            
        }
    
    public static void findASong(String a){
        String pattern = a;  // song searching for
       Pattern r  = Pattern.compile(pattern); // regular expression
       
       System.out.println("Songs Found");
       for(int i = 0; i < currentUser.numberOfSongs; i++   ){
           Matcher m = r.matcher(currentUser.album[i].getSongName());
           if(m.find()){
               System.out.println(currentUser.album[i]);
           }
       }
    }
    public static void displaySubAlbums(String a){
        int numberInAlbum = 0;  // counter for album with name passed in
        int counter = 0;  // counter for albums with name a
        for(int i = 0; i < currentUser.numberOfSongs;  i++){
            if(currentUser.album[i].getAlbumName().equals(a)){
                numberInAlbum++;
            }
        }
        copyArray = new Songs[numberInAlbum];
            
        for(int i = 0; i < currentUser.numberOfSongs;  i++){
            if(currentUser.album[i].getAlbumName().equals(a)){
                copyArray[counter] = currentUser.album[i];
                counter++;
            }
        }
        System.out.println("Album");
        for(int i = 1; i < (counter) + 1; i++){
            for(int j = 0; j < counter; j++){
               if(copyArray[j].getTrackNumber() == i){
                   // make a toString
                   System.out.println(copyArray[j].getTrackNumber() + ", " + copyArray[j].getSongName() + ", " + copyArray[j].getArtistName() + ", " + copyArray[j].getAlbumName());
               }
            }   
        }
    }
    
    public static void saveAlbums() throws FileNotFoundException, IOException{
         File f = new File("users.txt");    // file to store users
         PrintWriter pw = new PrintWriter(f);// print writer to write albums
         
        for(int i = 0; i < counter; i++){
            if(i < counter - 1){
                pw.println(users[i].userName);
            }
            else {
                pw.print(users[i].userName);
            }
               
        }
        pw.close();
                   
        File f1 = new File(currentUser.userName + ".txt");
        PrintWriter pw1 = new PrintWriter(f1);
        pw1.println(currentUser.numberOfSongs);
        for(int j = 0; j < currentUser.numberOfSongs; j++){
            pw1.println(currentUser.album[j]);
        } 
        pw1.close();         
    }   
     public static void computerUploadAlbum(String userName) throws FileNotFoundException{
            
        int numberOfSongs = 0; // num of songs to read in
        String songName;  // song name
        String artist;    // artist name
        String albumName;  // album name
        int trackNumber;  // track number
        
     
        File f1 = new File(userName + ".txt");
        if(f1.exists()){
           Scanner scan = new Scanner(f1);
        if(scan.hasNextLine()){
           numberOfSongs = scan.nextInt();
           currentUser.previousNumberOfSongs = currentUser.numberOfSongs; 
           currentUser.numberOfSongs = numberOfSongs + currentUser.numberOfSongs;
           scan.nextLine();        
        }
        scan.useDelimiter("[,\r\n]");
        
        for(int i = currentUser.previousNumberOfSongs; i < currentUser.numberOfSongs; i++){
            if(scan.hasNextLine()){
            trackNumber = scan.nextInt();
            songName = scan.next();    
            songName = songName.trim();
            artist = scan.next();     
            artist = artist.trim();
            albumName = scan.next();   
            albumName = albumName.trim();
            currentUser.album[i] = new Songs(trackNumber, songName, artist, albumName);
            scan.nextLine();
            scan.nextLine();
            }
        }
        }
    }   
}
