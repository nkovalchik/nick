/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication25;

/**
 *
 * @author Nick
 */
public class Songs implements Comparable<Songs>{
    private String albumName; 
    private int trackNumber;
    private String SongName;
    private String artistName;
    
    public Songs(int a, String b, String c, String d){
        trackNumber = a;
        SongName = b;
        artistName = c;
        albumName = d;
    }

    /**
     * @return the trackNumber
     */
    public int getTrackNumber() {
        return trackNumber;
    }
    
    @Override
    public String toString(){
        return trackNumber + ", " + SongName + ", " + artistName + ", " + albumName + "\n";
    }

    

    @Override
    public int compareTo(Songs other) {
        int result = this.getArtistName().compareTo(other.getArtistName());
        if(result < 0) result = -1;
        else if(result > 0) result = 1;
        else if (result == 0){
            result = this.getAlbumName().compareTo(other.getAlbumName());
            if(result < 0) result = -1;
            else if(result > 0) result = 1;
            else if(result == 0){
                if(this.getTrackNumber() < other.getTrackNumber()) result = -1;
                else if(this.getTrackNumber() > other.getTrackNumber()) result = 1;
                else{
                    result = 0;
                }
            }
        }
        return result;
    }

    /**
     * @return the albumName
     */
    public String getAlbumName() {
        return albumName;
    }

    /**
     * @return the SongName
     */
    public String getSongName() {
        return SongName;
    }

    /**
     * @return the artistName
     */
    public String getArtistName() {
        return artistName;
    }
}
