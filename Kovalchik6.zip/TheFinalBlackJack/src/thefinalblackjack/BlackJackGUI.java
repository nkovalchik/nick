/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thefinalblackjack;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.util.ArrayList;
import javax.swing.*;
import java.util.Calendar;
import java.awt.event.*;
import java.awt.Color;

/**
 *
 * @author nickkovalchik
 */
public class BlackJackGUI extends JFrame {

//make instances of the two StatData instances we want to keep track of which is the dealer and the player
   private Dstats dealerStats = new Dstats();
   private Pstats playerStats = new Pstats();
//set the default bet to 10
    private int currentBet = 10;

//setting up variable fields for left panel for the overall 1 by 3 gridlayout of the GUI
    private JPanel dealerImagePanel;
    private JPanel playerImagePanel;
    private JPanel leftPanel;
    private JTextField dealerLabel;
//setting up variable fields for middle panel for the overall 1 by 3 gridlayout of the GUI
    private JPanel middlePanel;
    private JPanel resultPanel = new JPanel(new GridLayout(3, 1, 1, 1));
    private JTextField results = new JTextField("Results");
//JTextFields that are add to the top of the result panel
    private JTextField  dealerResults;
    private JTextField playerResults;
//JButtons that are added to the middle panel as well
    private JButton hit = new JButton("Hit");
    private JButton sit = new JButton("Sit");
    private JTextField optionForNewGame;
    private JPanel yesNo;
    private JButton yes = new JButton("Yes");
    private JButton no = new JButton("No");
// right panel and its components
    private JPanel rightPanel;
    private JTextField playerLabel;
    private JPanel bettingBox = new JPanel(new BorderLayout());
    private JPanel buttonBox = new JPanel(new GridLayout(1, 4, 1, 1));
    private JRadioButton tenDollar = new JRadioButton("10", true);
    private JRadioButton twentyFiveDollar = new JRadioButton("25", false);
    private JRadioButton seventyFiveDollar = new JRadioButton("75", false);
    private JRadioButton hundredDollar = new JRadioButton("100", false);
    private ButtonGroup bettingGroup = new ButtonGroup();
// JTextField that will display the value of the players current cards or who won or lost the game
    private JTextField dealerResult;
//Actionlisteners for hit sit yes no buttons
    ActionListener playerAction = new ButtonAction();
    ActionListener continueGame = new ContinueAction();
//Itemlisteners for radioButtons
    ItemListener bettingChoice = new TheBet();

    Container pane = this.getContentPane();
//Make a playering deck of cards and player deck and dealer deck
    private Deck playingDeck = new Deck();
    private Deck playerDeck = new Deck();
    private Deck dealerDeck = new Deck();

    //private static ActionListener command = new CommandAction();
    public BlackJackGUI() {
//colors that I wanted the backgrounds to be
        Color VERY_DARK_GREEN = new Color(0, 102, 0);
        Color A_RED_COLOR = new Color(204, 0, 0);
//overall layout of the gui 
        setLayout(new GridLayout(1, 3));
//populated a playing deck and shuffle it
        playingDeck.makeADeck();
        playingDeck.shuffle();
//draw two cards for a player from the playing deck
        playerDeck.draw(playingDeck);
        playerDeck.draw(playingDeck);
//draw two cards for the dealers deck from the deck
        dealerDeck.draw(playingDeck);
        dealerDeck.draw(playingDeck);

//player starts at 21
        if (playerDeck.cardsValue() == 21) {
            hit.setEnabled(false);
            yes.setEnabled(true);
            no.setEnabled(true);
        }

// Make an image panel to add the dealers cards to
        dealerImagePanel = new JPanel(new GridLayout(2, 4, 1, 1));
        dealerImagePanel.add(dealerDeck.getjLabelArray().get(0));
//make top label for the dealer
        leftPanel = new JPanel(new BorderLayout());
        dealerLabel = new JTextField(20);
        dealerLabel.setText("Dealers Hand");
        dealerLabel.setHorizontalAlignment(SwingConstants.CENTER);
        dealerLabel.setEditable(false);
        dealerLabel.setColumns(13);
//make label at the bottom of leftpanel that displays the value of the players cards or how has one the game
        dealerResult = new JTextField(20);
        dealerResult.setText("");
        dealerResult.setHorizontalAlignment(SwingConstants.CENTER);
        dealerResult.setEditable(false);
        dealerResult.setColumns(13);

// add the dealer hand label to top of left panel
        leftPanel.add(dealerLabel, BorderLayout.NORTH);

// add to image panel to center of left panel
        leftPanel.add(dealerImagePanel, BorderLayout.CENTER);

// add result to bottom of left panel
        leftPanel.add(dealerResult, BorderLayout.SOUTH);
// add so color to left panel
        leftPanel.setBackground(VERY_DARK_GREEN);
// add color to dealerImagePanel
        dealerImagePanel.setBackground(VERY_DARK_GREEN);
// add left panel to the main container
        pane.add(leftPanel);
// Show the what to players cards are valued at
        dealerResult.setText("Your card value: " + playerDeck.cardsValue());
// create a panel to put hit, sit, JLabel, yes, other components
        JPanel resultPanel = new JPanel(new GridLayout(3, 1, 1, 1));
//create what is in result panel
        JTextField results = new JTextField("Results");
        dealerResults = new JTextField(dealerStats.getStats()); //stats of dealer
        playerResults = new JTextField(playerStats.getStats());//stats of player
        resultPanel.add(results);
        resultPanel.add(dealerResults);
        resultPanel.add(playerResults);
//creat layout for the whole middle panel and add the components
        middlePanel = new JPanel(new GridLayout(5, 1));
        middlePanel.add(resultPanel);
        middlePanel.add(hit);
        hit.addActionListener(playerAction);
        middlePanel.add(sit);
        sit.addActionListener(playerAction);
        optionForNewGame = new JTextField(20);
        optionForNewGame.setText("Do you want to play again.");
        optionForNewGame.setHorizontalAlignment(SwingConstants.CENTER);
        optionForNewGame.setEditable(false);
        optionForNewGame.setColumns(13);
        middlePanel.add(optionForNewGame);
        yesNo = new JPanel();
        yesNo.setLayout(new GridLayout(1, 2));
        yesNo.add(no);
// add actionListern to stop game
        no.addActionListener(continueGame);
// add actionListern to restart game
        yesNo.add(yes);
        yes.addActionListener(continueGame);
        middlePanel.add(yesNo);
//set enable to false
        yes.setEnabled(false);
        no.setEnabled(false);
// add color to middle panel
        middlePanel.setBackground(A_RED_COLOR);

// add middle panel to the pane
        pane.add(middlePanel);
// create the right panel
        rightPanel = new JPanel(new BorderLayout());
// create top label for right panel
        playerLabel = new JTextField(20);
        playerLabel.setText("Player hand");
        playerLabel.setHorizontalAlignment(SwingConstants.CENTER);
        playerLabel.setEditable(false);
        playerLabel.setColumns(13);
// create player image panel to display the cards and add card images to to panel
        playerImagePanel = new JPanel(new GridLayout(2, 4, 1, 1));
        playerImagePanel.add(playerDeck.getjLabelArray().get(0));
        playerImagePanel.add(playerDeck.getjLabelArray().get(1));

// add labels and image panel to right panel
        rightPanel.add(playerLabel, BorderLayout.NORTH);
        rightPanel.add(playerImagePanel);
//add color to righPanel
        rightPanel.setBackground(VERY_DARK_GREEN);
//add color to playerImagePanel
        playerImagePanel.setBackground(VERY_DARK_GREEN);
// create text field for betting
        JTextField bettingText = new JTextField(20);
        bettingText.setText("Pick your bet");
        bettingText.setHorizontalAlignment(SwingConstants.CENTER);
        bettingText.setEditable(false);
        bettingText.setColumns(13);
        bettingBox.add(bettingText, BorderLayout.NORTH);
//add the radio buttons action listeners
        tenDollar.addItemListener(bettingChoice);
        twentyFiveDollar.addItemListener(bettingChoice);
        seventyFiveDollar.addItemListener(bettingChoice);
        hundredDollar.addItemListener(bettingChoice);

        buttonBox.add(tenDollar);
        buttonBox.add(twentyFiveDollar);
        buttonBox.add(seventyFiveDollar);
        buttonBox.add(hundredDollar);

        bettingBox.add(buttonBox, BorderLayout.SOUTH);

        bettingGroup.add(tenDollar);
        bettingGroup.add(twentyFiveDollar);
        bettingGroup.add(seventyFiveDollar);
        bettingGroup.add(hundredDollar);

        rightPanel.add(bettingBox, BorderLayout.SOUTH);

        pane.add(rightPanel);
// create timer to update the textfields in the result panel
        Timer t = new Timer(100, new StatsListener());
        t.start();

    }
// make a handler for the hit sit buttons

    public class ButtonAction implements ActionListener {

        /*  This actionListener reacts when the hit or sit button is hit.  When hit is pressed a card is drawn from
    the playing deck an put into the players deck and its value is added to the players deck.  The drawn card
    is also added to a jLabelArray and redispayed.  If the players
    deck is 21 then the hit button is disabled because that is the perfect situation.  Else the button can
    be hit again until the player goes over twenty one where they would then loses and the hit and sit
    buttons are disabled or they are satified with there cards and press sit.  When sit is pressed it checks
    to see if the dealers hand is greater or equal to the players hand.  He keeps drawing until he wins ties
    or goes over twentyone. The drawn cards are also added to a jLabelArray and redispayed.  It then displayes 
    the result to the dealerResult text box.
    @param the action that is preformed
         */
        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == hit) {
                tenDollar.setEnabled(false);
                twentyFiveDollar.setEnabled(false);
                seventyFiveDollar.setEnabled(false);
                hundredDollar.setEnabled(false);

                playerDeck.draw(playingDeck);
                for (int i = 0; i < playerDeck.cardsToArrayList().size(); i++) {
                    playerImagePanel.add(playerDeck.getjLabelArray().get(i));
                }
                pane.validate();
                pane.repaint();

                if (playerDeck.cardsValue() == 21) {
                    hit.setEnabled(false);
                }

                if (playerDeck.cardsValue() > 21) {
                    dealerResult.setText("Sorry you lost");
                    dealerStats.setWins(dealerStats.getWins() + 1);
                    playerStats.setLoses(playerStats.getLoses() + 1);
                    subtractFromPot();
                    hit.setEnabled(false);
                    sit.setEnabled(false);
                    yes.setEnabled(true);
                    no.setEnabled(true);
                } else {
                    dealerResult.setText("Your hand value: " + playerDeck.cardsValue());
                }

            } else if (e.getSource() == sit) {
                yes.setEnabled(true);
                no.setEnabled(true);
                tenDollar.setEnabled(false);
                twentyFiveDollar.setEnabled(false);
                seventyFiveDollar.setEnabled(false);
                hundredDollar.setEnabled(false);

                for (int i = 0; i < dealerDeck.cardsToArrayList().size(); i++) {
                    dealerImagePanel.add(dealerDeck.getjLabelArray().get(i));
                }
                pane.validate();
                pane.repaint();

                int playerScore = playerDeck.cardsValue();
                if (dealerDeck.cardsValue() > playerDeck.cardsValue()) {

                    dealerResult.setText("\n" + "The dealer won.");
                    dealerStats.setWins(dealerStats.getWins() + 1);
                    playerStats.setLoses(playerStats.getLoses() + 1);
                    subtractFromPot();
                    hit.setEnabled(false);
                    sit.setEnabled(false);
                } else if (playerDeck.cardsValue() >= dealerDeck.cardsValue()) {
                    while (playerDeck.cardsValue() > dealerDeck.cardsValue() && dealerDeck.cardsValue() < 22) {
                        dealerDeck.draw(playingDeck);

                        for (int i = 0; i < dealerDeck.getjLabelArray().size(); i++) {
                            dealerImagePanel.add(dealerDeck.getjLabelArray().get(i));
                        }
                        pane.validate();
                        pane.repaint();
                    }

                    if (dealerDeck.cardsValue() > 21) {
                        dealerResult.setText("\n" + "The dealer busted you Won.");
                        playerStats.setWins(playerStats.getWins() + 1);
                        dealerStats.setLoses(dealerStats.getLoses() + 1);
                        addFromPot();
                        hit.setEnabled(false);
                        sit.setEnabled(false);
                    } else if (dealerDeck.cardsValue() > playerDeck.cardsValue()) {
                        dealerResult.setText("\n" + "The dealer Won.");
                        dealerStats.setWins(dealerStats.getWins() + 1);
                        playerStats.setLoses(playerStats.getLoses() + 1);
                        subtractFromPot();
                        hit.setEnabled(false);
                        sit.setEnabled(false);
                    } else if (playerDeck.cardsValue() == dealerDeck.cardsValue()) {
                        dealerResult.setText("\n" + "It is a push");
                        dealerStats.setTies(dealerStats.getTies() + 1);
                        playerStats.setTies(playerStats.getTies() + 1);

                        hit.setEnabled(false);
                        sit.setEnabled(false);
                    }

                }

            }

        }

    }
// make a handler for the yes and no buttons

    public class ContinueAction implements ActionListener {

        /*  If the player wants to play again they press yes and all the Arrays are cleared all the buttons are
    enabled to true.  The playing deck is only reset however is there are less then fiftyteen cards in 
    the deck.  Then cards are redrawn for the dealer deck and players deck. The Image panel also have to be
    repainted.
    @param the action that is preformed
         */

        @Override
        public void actionPerformed(ActionEvent e) {
            if (e.getSource() == yes) {
                if (playingDeck.sizeOfDeck() < 15) {
                    playingDeck.getCards().clear();
                    playingDeck.makeADeck();
                    playingDeck.shuffle();
                }

                dealerDeck.getCards().clear();
                dealerDeck.getImageIconArray().clear();
                dealerResult.setText("");
                dealerDeck.getjLabelArray().clear();
                playerDeck.getCards().clear();
                playerDeck.getImageIconArray().clear();
                playerDeck.getjLabelArray().clear();

                dealerImagePanel.removeAll();
                playerImagePanel.removeAll();

                hit.setEnabled(true);
                sit.setEnabled(true);
                tenDollar.setEnabled(true);
                twentyFiveDollar.setEnabled(true);
                seventyFiveDollar.setEnabled(true);
                hundredDollar.setEnabled(true);
                playerDeck.draw(playingDeck);
                playerDeck.draw(playingDeck);

                dealerDeck.draw(playingDeck);
                dealerDeck.draw(playingDeck);
                dealerResult.setText("Your card value: " + playerDeck.cardsValue());

                playerImagePanel.add(playerDeck.getjLabelArray().get(0));
                playerImagePanel.add(playerDeck.getjLabelArray().get(1));

                dealerImagePanel.add(dealerDeck.getjLabelArray().get(0));

                pane.validate();
                pane.repaint();

                if (playerDeck.cardsValue() == 21) {
                    hit.setEnabled(false);
                }
                yes.setEnabled(false);
                no.setEnabled(false);

            } else if (e.getSource() == no) {
                System.exit(0);

            }

        }

    }

// Itemlistener handler for radio buttons
    public class TheBet implements ItemListener {

        /*  If any of these radio buttons are pressed the current bet is changed to that number
    @param the action that is preformed
         */
        @Override
        public void itemStateChanged(ItemEvent e) {

            if (e.getSource() == tenDollar) {
                currentBet = 10;
            }
            if (e.getSource() == twentyFiveDollar) {
                currentBet = 25;
            }
            if (e.getSource() == seventyFiveDollar) {
                currentBet = 75;
            }
            if (e.getSource() == hundredDollar) {
                currentBet = 100;
            }
        }

    }
// ActionListener of the timer 

    public class StatsListener implements ActionListener {

        /*  DealerResult and PlayerResult textboxes are changed after a certain amount of time
    @param the action that is preformed
         */
        @Override
        public void actionPerformed(ActionEvent e) {
            dealerResults.setText(dealerStats.getStats());
            playerResults.setText(playerStats.getStats());

        }
    }

    /* 
   add to winnings
     */
    public void addFromPot() {
        playerStats.setWinnings(playerStats.getWinnings() + currentBet);
    }

    /* 
   subtracts to winnings
     */
    public void subtractFromPot() {
        playerStats.setWinnings(playerStats.getWinnings() - currentBet);
    }

}
