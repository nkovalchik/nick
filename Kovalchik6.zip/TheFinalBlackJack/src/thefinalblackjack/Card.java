/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thefinalblackjack;

/**
 *
 * @author nickkovalchik
 */
public class Card {
    private String rank;
    private String suit;
    
    public Card(String suit, String rank){
        this.rank = rank;
        this.suit = suit; 
                
    }
    
    public String toString(){
        String num = "";
        String sim = "";
        switch(rank){
            case "ace":
                num = "A";
                break;
            case "two":
                num = "2";
                break;
            case "three":
                num = "3";
                break;
            case "four":
                num = "4";
                break;
            case "five":
                num = "5";
                break;
            case "six":
                num = "6";
                break;
            case "seven":
                num = "7";
                break;
            case "eight":
                num = "8";
                break;
            case "nine":
                num = "9";
                break;
            case "ten":
                num = "10";
                break;
            case "king":
                num = "K";
                break;
            case "queen":
                num = "Q";
                break;
            case "jack":
                num = "J";
                break;
        }
        
        switch(suit){
            case "heart":
                sim = "H";
                break;
            case "spade":
                sim = "S";
                break;
            case "club":
                sim = "C";
                break;
            case "diamond":
                sim = "D";
                break;
            
        }
        
         return num + sim;
    }
    
    public String getValue(){
        return this.rank; 
    }
    
    
}
