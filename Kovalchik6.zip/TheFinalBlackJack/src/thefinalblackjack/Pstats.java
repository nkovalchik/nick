/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thefinalblackjack;

/**
 *
 * @author nickkovalchik
 */
public class Pstats extends Stats implements StatData {
    private String name = "Player";
    private int winnings = 0;
   
    
    @Override
    public String getStats() {
        
       return name + " wins: " + super.getWins() + " loses: " + super.getLoses() + " ties: " + super.getTies() + " Money: $" + winnings;
    }

    /**
     * @return the name
     */
    public String getName() {
        return name;
    }

    /**
     * @param name the name to set
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * @return the winnings
     */
    public int getWinnings() {
        return winnings;
    }

    /**
     * @param winnings the winnings to set
     */
    public void setWinnings(int winnings) {
        this.winnings = winnings;
    }
    
}
