/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thefinalblackjack;

import java.awt.*;
import javax.swing.*;

/**
 *
 * @author nickkovalchik
 */
public class TheFinalBlackJack {

    public static void main(String[] args) {
        BlackJackGUI game = new BlackJackGUI();
        game.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        game.setVisible(true);
        game.setSize(800, 300);
        game.setTitle("Blackjack");
        game.setResizable(true);

    }
}
