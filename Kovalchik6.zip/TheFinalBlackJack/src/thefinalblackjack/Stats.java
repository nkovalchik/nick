/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thefinalblackjack;

/**
 *
 * @author nickkovalchik
 */
public class Stats {
    private int wins = 0;
    private int loses  = 0;
    private int ties = 0;

    /**
     * @return the wins
     */
    public int getWins() {
        return wins;
    }

    /**
     * @return the loses
     */
    public int getLoses() {
        return loses;
    }

    /**
     * @param wins the wins to set
     */
    public void setWins(int wins) {
        this.wins = wins;
    }

    /**
     * @param loses the loses to set
     */
    public void setLoses(int loses) {
        this.loses = loses;
    }

    /**
     * @return the ties
     */
    public int getTies() {
        return ties;
    }

    /**
     * @param ties the ties to set
     */
    public void setTies(int ties) {
        this.ties = ties;
    }
            
}
