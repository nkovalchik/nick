/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thefinalblackjack;

/**
 *
 * @author nickkovalchik
 */
public class Dstats extends Stats implements StatData {

    
    
    @Override
    public String getStats() {
      return "Dealer wins: " + super.getWins() + " loses: " + super.getLoses() + " Ties: " + super.getTies(); 
    }
    
}
