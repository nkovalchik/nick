/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package thefinalblackjack;

import java.awt.Image;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.ImageIcon;
import javax.swing.JLabel;

/**
 *
 * @author nickkovalchik
 */
public class Deck {
    
// Rank and Suit arrays to populate Deck class
   private String[] rankArray = {"two", "three", "four", "five", "six", "seven", "eight", "nine", "ten", "jack", "queen", "king", "ace"};
   private String[] suitArray = {"club", "diamond", "spade", "heart"};

    private ImageIcon imageIcon;

    private ArrayList<ImageIcon> imageIconArray = new ArrayList<ImageIcon>();
    private ArrayList<JLabel> jLabelArray = new ArrayList<JLabel>();
    private ArrayList<Card> cards;

    public Deck() {
        this.cards = new ArrayList<Card>();
    }
    
//  create a deck of cards
    public void makeADeck() {
        for (int i = 0; i < suitArray.length; i++) {
            for (int j = 0; j < rankArray.length; j++) {
                this.getCards().add(new Card( suitArray[i], rankArray[j]));
            }
        }
    }

    //  make an arraylist of cards
        
    public ArrayList cardsToArrayList() {
        ArrayList<String> cardsToArray = new ArrayList<String>();
        for (int i = 0; i < getCards().size(); i++) {
            cardsToArray.add(getCards().get(i).toString());

        }
        return cardsToArray;
    }
// shuffle the deck
    public void shuffle() {
        ArrayList<Card> deckShuffle = new ArrayList<Card>();
        Random num = new Random();
        int ran = 0;
        for (int i = 0; i < 52; i++) {
            ran = num.nextInt((this.getCards().size() - 1 - 0) + 1) + 0;
            deckShuffle.add(this.getCards().get(ran));
            this.getCards().remove(ran);

        }
        this.cards = deckShuffle;

    }

    

    public void removeCard(int i) {
        this.getCards().remove(i);
    }

    public Card getcard(int i) {
        return this.getCards().get(i);
    }

    
/*  draw a card and remove it from the playing deck and make an Image Icon with the associated card so
    that you can display and add it to an Jlabel array
         */
    public void draw(Deck drawingFrom) {
        Card temp;
        temp = drawingFrom.getcard(0);

        this.getCards().add(drawingFrom.getcard(0));
        drawingFrom.removeCard(0);
        ImageIcon imageIconTemp;
        try {
// if this goes out of bounds (which it will) an exception is thrown
           imageIconTemp = new ImageIcon(getClass().getResource(temp.toString() + ".png"));
        } 
        catch (NullPointerException e) {
            System.out.println(e);
            System.out.println("ERROR READING IMAGE FILE.");
            
        }

        imageIconTemp = new ImageIcon(getClass().getResource(temp.toString() + ".png"));
        Image imageOne;
        imageOne = imageIconTemp.getImage().getScaledInstance(60, 100, Image.SCALE_SMOOTH);
        //create a new ImageIcon called imageIconOneResized with the with "imageOne" which is the resized image
        ImageIcon imageIconTempResized = new ImageIcon(imageOne);
        getImageIconArray().add(imageIconTempResized);
        // create a label that will be the correct size for the image
        getjLabelArray().add(new JLabel(imageIconTempResized));
        //put the icon in the label
        getjLabelArray().get(getjLabelArray().size() - 1).setIcon(imageIconTempResized);
    }
    
    
/* 
    add the values of the cards in a deck 
    @return the vaue of the all the cards
         */
    public int cardsValue() {
        int totalValue = 0;
        int aces = 0;

        for (int i = 0; i < this.getCards().size(); i++) {
            switch (this.getCards().get(i).getValue()) {
                case "two":
                    totalValue += 2;
                    break;
                case "three":
                    totalValue += 3;
                    break;
                case "four":
                    totalValue += 4;
                    break;
                case "five":
                    totalValue += 5;
                    break;
                case "six":
                    totalValue += 6;
                    break;
                case "seven":
                    totalValue += 7;
                    break;
                case "eight":
                    totalValue += 8;
                    break;
                case "nine":
                    totalValue += 9;
                    break;
                case "ten":
                    totalValue += 10;
                    break;
                case "jack":
                    totalValue += 10;
                    break;
                case "queen":
                    totalValue += 10;
                    break;
                case "king":
                    totalValue += 10;
                    break;
                case "ace":
                    aces += 1;
                    break;

            }
        }
        for (int i = 0; i < aces; i++) {
            if (totalValue > 10) {
                totalValue += 1;
            } else {
                totalValue += 11;
            }
        }
        return totalValue;
    }

    public int sizeOfDeck() {
        return this.getCards().size();
    }

   

    /**
     * @return the jLabelArray
     */
    public ArrayList<JLabel> getjLabelArray() {
        return jLabelArray;
    }

    /**
     * @return the cards
     */
    public ArrayList<Card> getCards() {
        return cards;
    }

    /**
     * @return the imageIcon
     */
    public ImageIcon getImageIcon() {
        return imageIcon;
    }

    /**
     * @return the imageIconArray
     */
    public ArrayList<ImageIcon> getImageIconArray() {
        return imageIconArray;
    }

}
