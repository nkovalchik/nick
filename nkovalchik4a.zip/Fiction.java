/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kovalchikn3;

/**
 *
 * @author nickkovalchik
 */
public class Fiction extends Book{
    private String author; // auther field of a book
    private String genre;// genre field of a book
    
    public Fiction(String title, String publisher, String pageCount, String author, String genre){
        super(title, publisher, pageCount);
        this.author = author;
        this.genre = genre;
        
    }
    
    //@param none
    //@return string
    // lets you output any book in an array in a good format
    @Override
    public String toString(){
       return (super.toString() + ", " + getAuthor() + ", " + getGenre());
   } 

    /**
     * @return the author
     */
    public String getAuthor() {
        return author;
    }

    /**
     * @return the genre
     */
    public String getGenre() {
        return genre;
    }
    
    
    
    //@param none
    //@return string
    // sends a elements of a book to be compared in compareTo method
    @Override
    public String getString(){
        return author + " " + super.getTitle();
    }
    
}
