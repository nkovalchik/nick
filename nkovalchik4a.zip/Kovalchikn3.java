// project2
// Nick Kovalchik
// 10/30/2018
// Course CSC2620-A
// This program takes in a batabase of books and lets you search for a book and display in in a sortred order
// Input database and what you want to search for
// Output books searched for
package kovalchikn3;

import java.io.FileNotFoundException;

/**
 *
 * @author nickkovalchik
 */
public class Kovalchikn3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws FileNotFoundException {
        // TODO code application logic here
        Library libaryOne = new Library();
        libaryOne.readInLibary();
        
        while(libaryOne.SearchForKind());
    }
    
}
