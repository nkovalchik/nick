/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kovalchikn3;

/**
 *
 * @author nickkovalchik
 */
public class GraphicNovel extends Fiction {
    private String illistrator; // illistrator of a book
    public GraphicNovel(String title, String publisher, String pageCount, String author, String genre, String illistrator){
        super(title, publisher, pageCount, author, genre);
        this.illistrator = illistrator;
    }
    //@param none
    //@return string
    // lets you output any book in an array in a good format
   public String toString(){
       return (super.toString() + ", " + getIllistrator());
   } 

    /**
     * @return the illistrator
     */
    public String getIllistrator() {
        return illistrator;
    }
    
     
    
}

