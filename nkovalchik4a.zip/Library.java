
package kovalchikn3;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 *
 * @author nickkovalchik
 */
public class Library {
    Book[] bookArray; // all the books in the database are put in this book array
    Book[] authorSubArray; //Is used as a copyarray for the sort by author
    Book[] genreSubArray; //Is used as a copyarray to sort by author
    Book[] illistratorSubArray; // Is used as a copyarray to sort by illistrator
    Book[] topicSubArray; // Is used as a copyarray to sort by topic
    Book [] regularExpression; // Is used as a copyarray to sort regularexpression
    
    Scanner in = new Scanner(System.in);
    int numberOfBooks;
    
    //@param none
    //@return none
    // reads in the database and puts it in an array
    public void readInLibary() throws FileNotFoundException{
File f = new File ("library.txt");
Scanner sc = new Scanner(f);
sc.useDelimiter("[,\r\n]");
if (sc.hasNextLine()){
   numberOfBooks = sc.nextInt();
   bookArray = new Book[numberOfBooks];
   sc.nextLine();
   
   for(int i = 0; i < numberOfBooks; i++){
      int bookType;
      String title;
      String publisher;
      String pageCount;
      String language;
      String topic;
      String author;
      String genre;
      String isPartOfASeries;
      String illistrator;
      bookType = sc.nextInt();
      switch(bookType){
          case 1: 
              title = sc.next().trim();
              publisher = sc.next().trim();
              pageCount = sc.next().trim();
              language = sc.next().trim();
              String versionNumber = sc.next().trim();
              bookArray[i] = new Dictionary(title, publisher, pageCount, language, versionNumber);
              break;
          case 2:
              title = sc.next().trim();
              publisher = sc.next().trim();
              pageCount = sc.next().trim();
              language = sc.next().trim();
              topic = sc.next().trim();
              bookArray[i] = new CookBook(title, publisher, pageCount, language, topic);
              break;
          case 3:
              title = sc.next().trim();
              publisher = sc.next().trim();
              pageCount = sc.next().trim();
              author = sc.next().trim();
              genre = sc.next().trim();
              isPartOfASeries = sc.next().trim();
              bookArray [i] = new Novel(title, publisher, pageCount, author, genre, isPartOfASeries);
              //System.out.println(author);
              break;
          case 4:
              title = sc.next().trim();
              publisher = sc.next().trim();
              pageCount = sc.next().trim();
              author = sc.next().trim();
              genre = sc.next().trim();
              illistrator = sc.next().trim();
              bookArray[i] = new GraphicNovel(title, publisher, pageCount, author, genre, illistrator);
              //System.out.println(author);
              break;
          
      }
      sc.nextLine(); 
   }
       
   
}
}
    //@param none
    //@return none
    public void printArray(){
        for(int i = 0; i < 11; i++){
            System.out.println(bookArray[i]);
        }
    }
    
    //@param none
    //@return none
    // search for books
    public Boolean SearchForKind(){
        boolean result = true;
        System.out.println("1. Search by Author");
        System.out.println("2. Search by genre");
        System.out.println("3. Search by illistrator");
        System.out.println("4. Search by topic");
        System.out.println("5. regular expression");
        System.out.println("6. exit");
        
        int choice = in.nextInt();
        switch(choice){
            case 1:
                int counter = 0;
                int counterTwo = 0;
                System.out.println("Enter an author.");
                in.nextLine();
                String name = in.nextLine();
                for(int i = 0; i < numberOfBooks; i++){
                    if(bookArray[i] instanceof Fiction){
                       Fiction kind = (Fiction) bookArray[i];
                        if(kind.getAuthor().equals(name)){
                            counter++;
                            
                        }
                    }
                }
                authorSubArray = new Book[counter];
                for(int i = 0; i < numberOfBooks; i++){
                    if(bookArray[i] instanceof Fiction){
                       Fiction kind = (Fiction) bookArray[i];
                        if(kind.getAuthor().equals(name)){
                            authorSubArray[counterTwo] = bookArray[i];
                            counterTwo++;
                        }
                    }
                }
                Arrays.sort(authorSubArray);
                for(int i = 0; i < counter; i++){
                    System.out.println(authorSubArray[i]);
                }
                 
                break;
            case 2:
                counter = 0;
                counterTwo = 0;
                System.out.println("Enter an genre.");
                in.nextLine();
                String nameTwo = in.nextLine();
                System.out.println(nameTwo);
                for(int i = 0; i < numberOfBooks; i++){
                    if(bookArray[i] instanceof Fiction){
                       Fiction kind = (Fiction) bookArray[i];
                        if(kind.getGenre().equals(nameTwo)){
                            counter++;
                            
                        }
                    }
                }
                genreSubArray = new Book[counter];
                for(int i = 0; i < numberOfBooks; i++){
                    if(bookArray[i] instanceof Fiction){
                       Fiction kind = (Fiction) bookArray[i];
                        if(kind.getGenre().equals(nameTwo)){
                            genreSubArray[counterTwo] = bookArray[i];
                            counterTwo++;
                            
                        }
                    }
                }
                Arrays.sort(genreSubArray);
                for(int i = 0; i < counter; i++){
                    System.out.println(genreSubArray[i]);
                }
                
                break;
                
            case 3:
                counter = 0;
                counterTwo = 0;
                System.out.println("Enter an illistrator.");
                in.nextLine();
                String nameThree = in.nextLine();
                for(int i = 0; i < numberOfBooks; i++){
                    if(bookArray[i] instanceof Fiction){
                        if(bookArray[i] instanceof GraphicNovel){
                            GraphicNovel kind = (GraphicNovel) bookArray[i];
                        if(kind.getIllistrator().equals(nameThree)){
                            counter++;
                        }
                      }
                    }
                }
                illistratorSubArray = new Book[counter];
                for(int i = 0; i < numberOfBooks; i++){
                    if(bookArray[i] instanceof Fiction){
                        if(bookArray[i] instanceof GraphicNovel){
                            GraphicNovel kind = (GraphicNovel) bookArray[i];
                        if(kind.getIllistrator().equals(nameThree)){
                            illistratorSubArray[counterTwo] = bookArray[i];
                                    counterTwo++;
                        }
                      }
                    }
                }
                Arrays.sort(illistratorSubArray);
                for(int i = 0; i < counter; i++){
                    System.out.println(illistratorSubArray[i]);
                }
                break;
                
            case 4:
                counter = 0;
                counterTwo = 0;
                System.out.println("Enter an topic.");
                in.nextLine();
                String nameFour = in.nextLine();
                for(int i = 0; i < numberOfBooks; i++){
                    if(bookArray[i] instanceof Nonfiction){
                        if(bookArray[i] instanceof CookBook){
                           CookBook kind = (CookBook) bookArray[i];
                           if(kind.getTopic().equals(nameFour)){
                               counter++;
                           }
                        }
                    }
                }
                topicSubArray = new Book[counter];
                for(int i = 0; i < numberOfBooks; i++){
                    if(bookArray[i] instanceof Nonfiction){
                        if(bookArray[i] instanceof CookBook){
                           CookBook kind = (CookBook) bookArray[i];
                           if(kind.getTopic().equals(nameFour)){
                               topicSubArray[counterTwo] = bookArray[i];
                           }
                        }
                    }
                }
                Arrays.sort(topicSubArray);
                for(int i = 0; i < counter; i++){
                    System.out.println(topicSubArray[i]);
                }
                
                break;
            case 5:
                counter = 0;
                counterTwo = 0;
                System.out.println("Enter the expression that you want to search for.");
                in.nextLine();
                String expression = in.nextLine();
                String pattern = expression;
                Pattern r = Pattern.compile(expression);
                
                System.out.println("Books Found");
                for(int i = 0; i < numberOfBooks; i++){
                    Matcher m = r.matcher(bookArray[i].getTitle());
                    if(m.find()){
                        counter++;
                    }
                }
                regularExpression = new Book[counter];
                for(int i = 0; i < numberOfBooks; i++){
                    Matcher m = r.matcher(bookArray[i].getTitle());
                    if(m.find()){
                        regularExpression[counterTwo] = bookArray[i];
                        counterTwo++;
                    }
                }
                
                Arrays.sort(regularExpression);
                
                for(int i = 0; i < counter; i++){
                    System.out.println(regularExpression[i]);
                }
                break;
                
            case 6:
                result = false;
                
                
        }
      return result;  
    }
    
    
}