/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kovalchikn3;

/**
 *
 * @author nickkovalchik
 */
public abstract class Book implements bookSort, Comparable<Book> {
    private String title; // title of the book
    private String publisher; // publisher of the book
    private String pageCount; // pageCount of the book
    
    public Book(String a, String b, String c){
        title = a;
        publisher = b;
        pageCount = c;
    }
    
    //@param a book
    //@return int
    // sorts array
    @Override
    public int compareTo(Book a){
        
        return this.getString().compareTo(a.getString());
            
        
    }
    
   
    
    //@param none
    //@return string
    //lets you output any book in an array in a good format
    @Override
    public String toString(){
       return (getTitle() + ", " + getPublisher() + ", " + getPageCount());
   } 

    /**
     * @return the title
     */
    public String getTitle() {
        return title;
    }

    /**
     * @return the publisher
     */
    public String getPublisher() {
        return publisher;
    }

    /**
     * @return the pageCount
     */
    public String getPageCount() {
        return pageCount;
    }
}
