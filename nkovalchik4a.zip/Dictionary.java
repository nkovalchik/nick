/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kovalchikn3;

/**
 *
 * @author nickkovalchik
 */
public class Dictionary extends Nonfiction {
    private String versionnum; // version of a nonfiction book
    public Dictionary(String title, String publisher, String pageCount, String language, String versionNum){
        super(title, publisher, pageCount, language);
                this.versionnum = versionNum;
    }
    //@param none
    //@return string
    // lets you output any book in an array in a good format
    @Override
    public String toString(){
       return (super.toString() + ", " + getVersionnum());
   } 

    /**
     * @return the versionnum
     */
    public String getVersionnum() {
        return versionnum;
    }
}
