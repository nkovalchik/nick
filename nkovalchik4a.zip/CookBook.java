/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kovalchikn3;

/**
 *
 * @author nickkovalchik
 */
public class CookBook extends Nonfiction{
    private String topic; // topic of a book
    public CookBook(String title, String publisher, String pageCount, String language, String topic){
        super(title, publisher, pageCount, language);
        this.topic = topic;
        
    }
    //@param none
    //@return string
    // lets you output any book in an array in a good format
    @Override
    public String toString(){
       return (super.toString() + ", " + getTopic());
   } 

    /**
     * @return the topic
     */
    public String getTopic() {
        return topic;
    }
}
