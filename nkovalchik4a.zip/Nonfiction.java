/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kovalchikn3;

/**
 *
 * @author nickkovalchik
 */
public class Nonfiction extends Book {
    private String language; // language of a book
    
    public Nonfiction(String title, String publisher, String pageCount, String language){
        super(title, publisher, pageCount);
        this.language = language;
    }
    
    //@param none
    //@return string
    // lets you output any book in an array in a good format
    @Override
    public String toString(){
       return (super.toString() + ", " + getLanguage());
   } 

    /**
     * @return the language
     */
    public String getLanguage() {
        return language;
    }
 
    //@param none
    //@return string
    // sends a element of a book to compareTo method
    @Override
    public String getString() {
        
        return language + " "  + super.getTitle(); 
    }

    
    
    
}
