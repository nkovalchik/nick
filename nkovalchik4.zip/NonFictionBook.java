//NonFictionBook.java
//Nick Kovalchik
//Date: 2/29/13
//Course: CSC2620
//Descripition this file provides the class that decribes
//the book class FictionBook and implements comparable
package project3;


public class NonFictionBook extends Book {
    private String Language; // Added field to Nonfiction
    
   public NonFictionBook(String title, String publisher, String pageCount, String language){
        super(title, publisher, pageCount);
        Language = language;
       
    }
      
   // This method overides the compareTo method
  // @Override
  // public int compareTo(NonFictionBook other) {
   //     if (this == other) {
     //       return 0;
   //     }

     //   if (this.getLanguage().compareTo(other.getLanguage()) < 0) {
     //       return -1;
     //   } else if (this.getLanguage().compareTo(other.getLanguage()) > 0) {
     //       return 1;
     //   } else if (this.getTitle().compareTo(other.getTitle()) < 0) {
     //       return -1;
     //   } else if (this.getTitle().compareTo(other.getTitle()) > 0) {
     //       return 1;
        
     //   } else {
     //       return 0;
     //   }
  //  }

    /**
     * @return the Language
     */
    public String getLanguage() {
        return Language;
    }
}
