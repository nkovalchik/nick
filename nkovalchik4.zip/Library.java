//Dictionary.java
//Nick Kovalchik
//Date: 2/29/13
//Course: CSC2620
//Descripition this file provides the class that reads in and process the search request

package project3;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.Scanner;

/**
 *
 * @author nickkovalchik
 */
public class Library{
Scanner scannername = new Scanner(System.in);
Book [] bookArray;
int bookType;
String title;
String publisher;
String pageCount;

// This method reads in the books and allows the user to choose what to search for.

public void readInLibary() throws FileNotFoundException{
File f = new File ("/Users/nickkovalchik/NetBeansProjects/Project3/" + "library.txt");
Scanner sc = new Scanner(f);
sc.useDelimiter("[,\r\n]");
if (sc.hasNextLine()){
   int numberOfBooks;
   numberOfBooks = sc.nextInt();
   bookArray = new Book[numberOfBooks];
   sc.nextLine();
   
   for(int i = 0; i < numberOfBooks; i++){
        bookType = sc.nextInt();
        title = sc.next().trim();
        publisher = sc.next().trim();
        pageCount = sc.next().trim();
        switch(bookType){
            case 1:
                String language = sc.next().trim();
                String versionNumber = sc.next().trim();
                bookArray[i] = new Dictionary(title, publisher, pageCount, language, versionNumber);
                break;
            case 2:  
                language = sc.next().trim();
                String topic = sc.next().trim();
                bookArray[i] = new Cookbook(title, publisher, pageCount, language, topic);
                break;
            case 3: 
                String author = sc.next().trim();
                String genre = sc.next().trim();
                String isPartOfASeries = sc.next().trim();
                bookArray[i] = new Novel (title, publisher, pageCount, author, genre, isPartOfASeries  );
                break;
            case 4:
                author = sc.next().trim();
                genre = sc.next().trim();
                String illustration = sc.next().trim();
                bookArray[i] = new GraphicNovel (title, publisher, pageCount, author, genre, illustration);
                break;
                

   }
        sc.nextLine(); 
           
   }
   for(int i = 0; i < numberOfBooks; i++){
       System.out.println(bookArray[i]);
   }
    
}


while(true){
    Book [] genreArray = new Book [10];
    Book [] topicArray = new Book [10];
    Book [] illustratorArray = new Book[10];
    int genreCounter = 0;
    int illustratorCounter = 0;
    int topicCounter = 0;

    System.out.println("Choice a number.");
    System.out.println("");
    System.out.println("1. Search by book title.");
    System.out.println("2. Search by genre.");
    System.out.println("3. Search by illustrator.");
    System.out.println("4. Search by topic.");
    System.out.println("5. Exit");
   
    
    int choice = scannername.nextInt();
    switch(choice){
        case 1: 
            System.out.println("Enter the title of the book.");
            scannername.nextLine();
            String name = scannername.nextLine();
            for(int i = 0; i < bookArray.length; i++ ){
                if(bookArray[i].getTitle().compareTo(name) == 0) {
                    System.out.println(bookArray[i]);
                    
                }
                
            }
            break;
            
        case 2:
            System.out.println("Enter the genre.");
            scannername.nextLine();
            name = scannername.nextLine();
            for(int i = 0; i < bookArray.length; i++ ){
                if(bookArray[i] instanceof FictionBook){
                    FictionBook isFiction = (FictionBook) bookArray[i];
                    
                if(isFiction.getGenre().compareTo(name) == 0){
                    genreArray[genreCounter] = (Book)isFiction;
                   
                    genreCounter++;
                    
                }    
                    
                }
            }
            Book [] genreCopyArray = new Book [genreCounter];
            for(int i = 0; i < genreCounter; i++){
              
              
                genreCopyArray[i] = (Book)genreArray[i]; 
            }
           Arrays.sort(genreCopyArray);
            
            for(int i = 0; i < genreCounter; i++){
                System.out.println(genreCopyArray[i]);
            }
            break;
            
        case 3:
            System.out.println("Enter the illustrator.");
            scannername.nextLine();
            name = scannername.nextLine();
            
            for(int i = 0; i < bookArray.length; i++ ){
                if(bookArray[i] instanceof FictionBook){
                    if (bookArray[i] instanceof GraphicNovel){
                        
                    
                    GraphicNovel isGraphicNovel = (GraphicNovel) bookArray[i];
                    
                if(isGraphicNovel.getIllustrator().compareTo(name) == 0){
                    illustratorArray[illustratorCounter] = isGraphicNovel;
                    illustratorCounter++;
                    
                  }    
                }   
              }
            }
            for(int i = 0; i < illustratorCounter; i++){
                System.out.println(illustratorArray[i]);
              }
            break;
            
        case 4:
            System.out.println("Enter the topic.");
            name = scannername.nextLine();
            name = scannername.nextLine();
            
            for(int i = 0; i < bookArray.length; i++ ){
                if(bookArray[i] instanceof NonFictionBook){
                    if (bookArray[i] instanceof Cookbook){
                        
                    
                    Cookbook isCookbook = (Cookbook) bookArray[i];
                if(isCookbook.getTopic().compareTo(name) == 0){
                    topicArray[topicCounter] = isCookbook;
                    topicCounter++;
                    
                }    
               }   
              }
            }
            for(int i = 0; i < topicCounter; i++){
                System.out.println(topicArray[i]);
            }
            break;
            
        case 5:
            return;
        
        
    }
}


}

}



