//Dictionary.java
//Nick Kovalchik
//Date: 2/29/13
//Course: CSC2620
//Descripition this file provides the class that decribes
//the book class dictionary


package project3;


public class Dictionary extends NonFictionBook {
private String VersionNmber; // Last fielded in Dictionary
    
public Dictionary(String title, String publisher, String pageCount,
        String language, String versionNumber ){
super(title, publisher, pageCount, language );
 VersionNmber = versionNumber;
    
}

// This method overides the toString method
@Override
 public String toString(){
       return (Title + ", " + Publisher + ", " + PageCount + ", " + getLanguage() + ", " + VersionNmber );
       
   }
    
    
}
