//Ficionbook.java
//Nick Kovalchik
//Date: 2/29/13
//Course: CSC2620
//Descripition this file provides the class that decribes
//the book class FictionBook and implements comparable

package project3;


public class FictionBook extends Book implements Comparable<FictionBook> {
    protected String  Author;
    protected String Genre; // The two added field for FictionBook
    
    public FictionBook(String title, String publisher, 
            String pageCount, String author, String genre) {
        super(title, publisher, pageCount);
        Author = author;
        Genre = genre;
    }

    /**
     * @return the Author
     */
    public String getAuthor() {
        return Author;
    }
 

    /**
     * @return the Genre
     */
    public String getGenre() {
        return Genre;
    }

    // This method overides the compare method
    @Override
    public int compareTo(FictionBook other) {
        if (this == other) {
            return 0;
        }

        if (this.Author.compareTo(other.getAuthor()) < 0) {
            return -1;
        } else if (this.Author.compareTo(other.getAuthor()) > 0) {
            return 1;
        } else if (this.getTitle().compareTo(other.getTitle()) < 0) {
            return -1;
        } else if (this.getTitle().compareTo(other.getTitle()) > 0) {
            return 1;
        
        } else {
            return 0;
        }
    }
    
}
