/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package project3;

import java.io.FileNotFoundException;


public class Project3 {

   // This is the main program that creates the library and allows people to search
    public static void main(String[] args) throws FileNotFoundException {
        
        Library library1 = new Library();
        library1.readInLibary();
        
    }
    
}
