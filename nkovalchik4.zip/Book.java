//Book.java
//Nick Kovalchik
//Date: 2/29/13
//Course: CSC2620
// This file descripes the super class Book

package project3;


public class Book  {
    protected String Title; //First emlement in line
    protected String Publisher; //Second element in Line
    protected String PageCount; //Third element in Line
    
    public Book(String title, String publisher, String pageCount ){
        Title = title;
        Publisher = publisher;
        PageCount = pageCount;
        
    }

    /**
     * @return the title
     */
    public String getTitle() {
        return Title;
    }

    /**
     * @param title the title to set
     */
    public void setTitle(String title) {
        this.Title = title;
    }

    /**
     * @return the publisher
     */
    public String getPublisher() {
        return Publisher;
    }


    /**
     * @return the pageCount
     */
    public String getPageCount() {
        return PageCount;
    }

    
}
