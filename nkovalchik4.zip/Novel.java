//Novel.java
//Nick Kovalchik
//Date: 2/29/13
//Course: CSC2620
//Descripition this file provides the class that decribes
//the Novel class return all th novels
package project3;


public class Novel extends FictionBook {
    
    private String IsPartOfASeries; // last field for Novel
    public Novel(String title, String publisher, String pageCount, String author,
            String genre, String isPartOfASeries){
        super(title, publisher, pageCount, author, genre);
        IsPartOfASeries = isPartOfASeries;
    }
    @Override
    public String toString(){
       return (Title + ", " + Publisher + ", " + PageCount + ", " + Author + ", " + Genre + ", " + IsPartOfASeries );
       
   }
}
