//Cookbook.java
//Nick Kovalchik
//Date: 2/29/13
//Course: CSC2620
//Descripition this file provides the class that decribes
//the book class CookBook
package project3;


public class Cookbook extends NonFictionBook {

    
  private String Topic; // last element for a cookbook
  
  public Cookbook(String title, String publisher, String pageCount,
          String language, String topic){
  super(title, publisher, pageCount, language );
  Topic = topic;
  }
  
  
  /**
     * @return the Topic
     */
    public String getTopic() {
        return Topic;
    }
  
  @Override
  public String toString(){
       return (Title + ", " + Publisher + ", " + PageCount + ", " + getLanguage() + ", " + getTopic() );
       
   } 

   
}
