
package kovalchikn5;

import java.util.ArrayList;

/**
 *
 * @author nickkovalchik
 */
public abstract class Person implements Status {
    private String name;  //family members name
    private String birthday; // family members birthday
    private Person parentOne;  // One parents object
    private Person partentTwo; // Second parents object
    private Person spouse;  // if they have a spouse that person object
    private ArrayList<Person> children = new ArrayList<Person>();  // array of all the children of a family member
    
    
    
    public Person(String name, String birthday){
        this.name = name;
        this.birthday = birthday;
        
    }
    
    // gets objects information
    //@param none
    //@return persons info
    @Override
    public String toString(){
       return name + ", " + birthday + ", " + getStatus();
    }
    
    

    
    public void setName(String name) {
        this.name = name;
    }

    
    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }


    
    public void setSpouse(Person spouse) {
        this.spouse = spouse;
    }

    
    public void setChildren(ArrayList<Person> children) {
        this.children = children;
    }

   
   

    
    public String getName() {
        return name;
    }

    
    public String getBirthday() {
        return birthday;
    }
    

    
    public Person getSpouse() {
        return spouse;
    }

   
    public ArrayList<Person> getChildren() {
        return children;
    }

    
    public Person getParentOne() {
        return parentOne;
    }

    
    public Person getPartentTwo() {
        return partentTwo;
    }

    
    public void setParentOne(Person parentOne) {
        this.parentOne = parentOne;
    }

    
    public void setPartentTwo(Person partentTwo) {
        this.partentTwo = partentTwo;
    }
    
    
}
