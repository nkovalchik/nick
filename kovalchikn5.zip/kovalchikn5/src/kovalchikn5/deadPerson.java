/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package kovalchikn5;

/**
 *
 * @author nickkovalchik
 */
public class deadPerson extends Person {
    private String deathDate;  // day person died info
   public deadPerson(String name, String birthday, String deathDate ){
       super(name, birthday);
       this.deathDate = deathDate;
   }
   
   
    
    //@param none
    //@returns deathDate to toString
    @Override
    public String getStatus(){
        return deathDate;
    }
   

    
    public String getDeathDate() {
        return deathDate;
    }

    
    public void setDeathDate(String deathDate) {
        this.deathDate = deathDate;
    }

    
}
