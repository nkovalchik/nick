
package kovalchikn5;

/**
 *
 * @author nickkovalchik
 */
public class LivingPerson extends Person {
    private String town;  // town the person lives in
    private String state; // state the person lives in
    
    public LivingPerson(String name, String birthday, String town, String state ){
        super(name, birthday);
        this.town = town;
        this.state = state;
    
}
    
     
    

    
    // getStatus is a interface function that gets the proper information depending on if they are a living or dead person
    //@param none
    //@returns living persons info
    @Override
    public String getStatus(){
        return town + ", " + state;
    }
    
}
