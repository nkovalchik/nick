//Project5.cpp
//Nick Kovalchik
//CSC2620-A
/* This program lets a client create there own famliy tree and add as many familys members as they
// want and there relaitons.  Then they can print out the whole tree, just one persons restions to the family
   and be able to ajust the tree as family circumstances change
*/
// Input clients and there family members
// Output there realtionships and 
package kovalchikn5;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author nickkovalchik
 */
public class Kovalchikn5 {

    static ArrayList<Family> clientArray = new ArrayList<Family>(); // array of clients
    static Family current; // The current user
    static int counter = 0;

    public static void main(String[] args)  {
        try {
            Scanner in = new Scanner(System.in);
            boolean resultTwo = true;
            boolean result = true;
            int found = 0;
            
            File f1 = new File("users1.txt");
            //if (f1.exists()) {
            Scanner sc = new Scanner(f1);
            System.out.println("The previous client are: ");
            while (sc.hasNextLine()) {
                String name = sc.next();
                clientArray.add(new Family(name));
                System.out.println("Client name: " + name);
            }

            for (int i = 0; i < clientArray.size(); i++) {
                String familyName = clientArray.get(i).familyName;
                clientArray.get(i).readInFile(familyName + ".txt");
            }
            
            // }
            
            do {
                //Menu to add and pick cients from the client array
                resultTwo = true;
                System.out.println("1. Add a client ");
                System.out.println("2. Pick a client");
                System.out.println("3. exit");
                int choice = in.nextInt();
                switch (choice) {
                    case 1:
                        System.out.println("Enter cleints family name");
                        String name = in.next();
                        clientArray.add((new Family(name)));
                        
                        break;
                        
                    case 2:
                        for (int i = 0; i < clientArray.size(); i++) {
                            System.out.println(clientArray.get(i).familyName);
                        }
                        System.out.println("Enter the user you want");
                        String pick = in.next();
                        for (int i = 0; i < clientArray.size(); i++) {
                            
                            if (pick.equals(clientArray.get(i).familyName)) {
                                current = clientArray.get(i);
                                found = 1;
                                break;  
                            }
                        }
                        if (found != 1) {
                            System.out.println("User not found, please re-run");
                            break;
                        }
                        
                        do {
                            // Menue for each user to preform diffent actions on the family tree
                            System.out.println("Pick a number");
                            System.out.println("1. Add to the family tree by typing file name");
                            System.out.println("2. Delete from the family tree");
                            System.out.println("3. Print out whole family tree");
                            System.out.println("4. Search for one person realionships by entering there name");
                            System.out.println("5. Change someone from living to dead by entering there name");
                            System.out.println("6. Exit");
                            
                            int choiceTwo = in.nextInt();
                            switch (choiceTwo) {
                                case 1:
                                    System.out.println("Enter the file name");
                                    String fileName = in.next();
                                    current.readInFile(fileName);
                                    break;
                                case 2:
                                    System.out.println("Enter the family member that you want to delete.");
                                    in.nextLine();
                                    String deletedPerson = in.nextLine();
                                    deletedPerson.trim();
                                    current.deleteSomeOne(deletedPerson);
                                    break;
                                    
                                case 3:
                                    
                                    current.PrintOutWholeTree();
                                    
                                    break;
                                    
                                case 4:
                                    System.out.println("Enter a person to get there family");
                                    in.nextLine();
                                    String nameTwo = in.nextLine();
                                    nameTwo.trim();
                                    current.searchForRelationships(nameTwo);
                                    break;
                                    
                                case 5:
                                    System.out.println("Enter who died");
                                    in.nextLine();
                                    String personThatDied = in.nextLine();
                                    personThatDied.trim();
                                    System.out.println("Enter the date of death");
                                    String dateOfdeath = in.nextLine();
                                    dateOfdeath.trim();
                                    current.changeToDead(personThatDied, dateOfdeath);
                                    
                                    break;
                                    
                                case 6:
                            {
                                try {
                                    current.printToFile();
                                } catch (IOException ex) {
                                    System.out.println("The file can not be written to");
                                }
                            }
                                    resultTwo = false;
                                    break;
                                    
                            }
                        } while (resultTwo);
                        break;
                        
                    case 3:
                {
                    writeOutUsers();
                }
                        result = false;
                        
                }
                
            } while (result);
        } catch (FileNotFoundException ex) {
            System.out.print("The file can not be found.");
        }
        catch(InputMismatchException e){
            System.out.println("You entered the wrong thing.");
        }
        catch(IndexOutOfBoundsException e){
            System.out.println("Array element does not exist");
        }

    }

    // This functions wirtes out to a file for the users to be saved
    //@param none
    //@return void
    public static void writeOutUsers() {
        PrintWriter pw = null;
        try {
            File f = new File("users1.txt");    // file to store users
            pw = new PrintWriter(f); // print writer to write albums
            for (int i = 0; i < clientArray.size(); i++) {
                if (i != clientArray.size() - 1) {
                    pw.println(clientArray.get(i).familyName);
                } else {
                    pw.print(clientArray.get(i).familyName);
                }
            }   pw.close();
        } catch (FileNotFoundException ex) {
            System.out.println("The file can not be found");
        } finally {
            pw.close();
        }

    }

}
