
package kovalchikn5;

/**
 *
 * @author nickkovalchik
 */
public interface Status {
    public String getStatus();
  
    
}
