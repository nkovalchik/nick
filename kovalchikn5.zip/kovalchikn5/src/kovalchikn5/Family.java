package kovalchikn5;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author nickkovalchik
 */
public class Family {

    ArrayList<Person> personArray = new ArrayList<Person>();  // array of all the family members in the tree
    String familyName; //  clients username

    public Family(String family) {
        this.familyName = family;
    }

    // This funtion reads in a file and contains family members and there relationships to eachother
    //@param none
    //@return void
    public void readInFile(String file) {
        try {
            String name;
            String birthday;
            String addressOrDead;
            String city;
            String state;

            File f = new File(file);
            Scanner sc = new Scanner(f);
            sc.useDelimiter("[,\r\n]");

            while (sc.hasNext()) {

                name = sc.next();
                name = name.trim();

                if (name.compareTo("") == 0) {
                    break;
                }

                birthday = sc.next().trim();
                addressOrDead = sc.next().trim();
                if (addressOrDead.matches("[0-9 ]+")) {
//If the person is has a death date a dead person object is created
                    deadPerson addPerson = new deadPerson(name, birthday, addressOrDead);
                    personArray.add(addPerson);
                } else {
//If there is town and state a living person object is created
                    state = sc.next().trim();
                    LivingPerson add = new LivingPerson(name, birthday, addressOrDead, state);
                    personArray.add(add);
                }

            }

            while (sc.hasNextLine()) {
                Person temp = null;
                String nameTwo;
                String relationship;
                name = sc.next();
                name = name.trim();

                for (int i = 0; i < personArray.size(); i++) {
                    if (name.equals(personArray.get(i).getName())) {
                        relationship = sc.next();
                        relationship = relationship.trim();
                        nameTwo = sc.next();
                        nameTwo = nameTwo.trim();

                        if (relationship.equals("parentof")) {
//If the system reads in parentof a child is added to that person and that parent is added to that childs parent
                            for (int j = 0; j < personArray.size(); j++) {
                                if (nameTwo.equals(personArray.get(j).getName())) {
                                    if (personArray.get(j).getParentOne() == null) {
                                        personArray.get(j).setParentOne(personArray.get(i));
                                        //System.out.println(personArray.get(j).getName() + " parent is  " + personArray.get(i).getName());
                                    } else {
                                        personArray.get(j).setPartentTwo(personArray.get(i));
                                    }
                                    temp = personArray.get(j);
                                    ArrayList a = personArray.get(i).getChildren();
                                    a.add(temp);
                                    break;
                                }

                            }

                        } else if (relationship.equals("marriedto")) {
//If the system reads in married the to people that were read in the there spouses field set to eachother
                            for (int j = 0; j < personArray.size(); j++) {
                                if (nameTwo.equals(personArray.get(j).getName())) {
                                    personArray.get(j).setSpouse(personArray.get(i));
                                    personArray.get(i).setSpouse(personArray.get(j));
                                    break;
                                }
                            }
                        }

                    }
                    //break;
                }
            }
        } catch (FileNotFoundException ex) {
            System.out.println("File can not be found please add the file");
        } catch (InputMismatchException s) {
            System.out.println("The input in the file is not correct");
        }

    }

    // prints out all the people in the tree
    //@param none
    //@return void
    public void printOutlist() {

        for (Person str : personArray) {
            System.out.println(str);
            System.out.println();
        }
    }

    // prints out all people and there spouse and children
    //@param none
    //@return void
    public void prinRealitionships() {
        System.out.println(personArray.size());
        for (int i = 0; i < personArray.size(); i++) {

            System.out.println(personArray.get(i).getName() + ", " + personArray.get(i).getBirthday()
                    + ", " + personArray.get(i).getStatus());

            if (personArray.get(i).getSpouse() != null) {
                System.out.println("Spouse " + personArray.get(i).getSpouse().getName());
            }
            if (!personArray.get(i).getChildren().isEmpty()) {
                for (int j = 0; j < personArray.get(i).getChildren().size(); j++) {
                    System.out.println("Child " + personArray.get(i).getChildren().get(j));
                }
            }

        }
    }

    // get all of one persons relationships in the family tree
    //@param name of person that you want to get there relationships in the family treee
    //@return void
    public void searchForRelationships(String name) {
        ArrayList<Person> auntsAndUncles = new ArrayList<Person>();
        ArrayList<Person> grandParents = new ArrayList<Person>();
        ArrayList<Person> parents = new ArrayList<Person>();
        ArrayList<Person> nieceAndNephews = new ArrayList<Person>();
        ArrayList<Person> childrenArray = new ArrayList<Person>();
        String grandParentOne = null;
        String grandParentTwo = null;
        String grandParentThree = null;
        String grandParentFour = null;
        String parentOne = null;
        String parentTwo = null;
        Scanner sc = new Scanner(System.in);

        for (int i = 0; i < personArray.size(); i++) {
            if (name.equals(personArray.get(i).getName())) {
                if (personArray.get(i).getParentOne() != null) {
                    parents.add(personArray.get(i).getParentOne());
                    parentOne = personArray.get(i).getParentOne().getName();
                }
                if (personArray.get(i).getPartentTwo() != null) {
                    parents.add(personArray.get(i).getPartentTwo());
                    parentTwo = personArray.get(i).getPartentTwo().getName();
                }

            }
        }
        System.out.println("Parents :");
        for (int i = 0; i < parents.size(); i++) {
            System.out.println(parents.get(i));
        }

        //Searching for GrandParents from one side
        for (int i = 0; i < personArray.size(); i++) {

            if (parentOne != null && parentOne.equals(personArray.get(i).getName())) {
                if (personArray.get(i).getParentOne() != null) {
                    grandParentOne = personArray.get(i).getParentOne().getName();
                    grandParents.add(personArray.get(i).getParentOne());
                }
                if (personArray.get(i).getPartentTwo() != null) {
                    grandParentTwo = personArray.get(i).getPartentTwo().getName();
                    grandParents.add(personArray.get(i).getPartentTwo());
                }
            }
        }

        for (int i = 0; i < personArray.size(); i++) {
            if (parentTwo != null && parentTwo.equals(personArray.get(i).getName())) {
                if (personArray.get(i).getParentOne() != null) {
                    grandParentThree = personArray.get(i).getParentOne().getName();
                    grandParents.add(personArray.get(i).getParentOne());

                }
                if (personArray.get(i).getPartentTwo() != null) {
                    grandParentFour = personArray.get(i).getPartentTwo().getName();
                    grandParents.add(personArray.get(i).getPartentTwo());
                }
            }

        }
        System.out.println("GrandParents :");
        for (int i = 0; i < grandParents.size(); i++) {
            System.out.println(grandParents.get(i));
        }

        for (int i = 0; i < personArray.size(); i++) {
            if (grandParentOne != null && grandParentOne.equals(personArray.get(i).getName())) {
                for (int j = 0; j < personArray.get(i).getChildren().size(); j++) {
                    if (!parentOne.equals(personArray.get(i).getChildren().get(j).getName()) && !parentTwo.equals(personArray.get(i).getChildren().get(j).getName())) {
                        if (!auntsAndUncles.contains(personArray.get(i).getChildren().get(j))) {
                            auntsAndUncles.add(personArray.get(i).getChildren().get(j));
                        }
                    }
                }
            }
            if (grandParentTwo != null && grandParentTwo.equals(personArray.get(i).getName())) {
                for (int j = 0; j < personArray.get(i).getChildren().size(); j++) {
                    if (!parentOne.equals(personArray.get(i).getChildren().get(j).getName()) && !parentTwo.equals(personArray.get(i).getChildren().get(j).getName())) {
                        if (!auntsAndUncles.contains(personArray.get(i).getChildren().get(j))) {
                            auntsAndUncles.add(personArray.get(i).getChildren().get(j));
                        }
                    }
                }
            }
            if (grandParentThree != null && grandParentThree.equals(personArray.get(i).getName())) {
                for (int j = 0; j < personArray.get(i).getChildren().size(); j++) {
                    if (!parentOne.equals(personArray.get(i).getChildren().get(j).getName()) && !parentTwo.equals(personArray.get(i).getChildren().get(j).getName())) {
                        if (!auntsAndUncles.contains(personArray.get(i).getChildren().get(j))) {
                            auntsAndUncles.add(personArray.get(i).getChildren().get(j));
                        }
                    }
                }
            }

            if (grandParentFour != null && grandParentFour.equals(personArray.get(i).getName())) {
                for (int j = 0; j < personArray.get(i).getChildren().size(); j++) {
                    if (!parentOne.equals(personArray.get(i).getChildren().get(j).getName()) && !parentTwo.equals(personArray.get(i).getChildren().get(j).getName())) {
                        if (!auntsAndUncles.contains(personArray.get(i).getChildren().get(j))) {
                            auntsAndUncles.add(personArray.get(i).getChildren().get(j));
                        }
                    }
                }
            }
        }
        System.out.println("Aunts and Uncles :");
        for (int i = 0; i < auntsAndUncles.size(); i++) {
            System.out.println(auntsAndUncles.get(i));
        }

        if (parents != null) {
            for (int i = 0; i < parents.size(); i++) {
                for (int j = 0; j < parents.get(i).getChildren().size(); j++) {
                    if (parents.get(i).getChildren() != null) {
                        for (int g = 0; g < parents.get(i).getChildren().get(j).getChildren().size(); g++) {
                            if (!nieceAndNephews.contains(parents.get(i).getChildren().get(j).getChildren().get(g))) {
                                nieceAndNephews.add(parents.get(i).getChildren().get(j).getChildren().get(g));
                            }
                        }
                    }
                }
            }
            System.out.println("Nices and Nephews :");
            for (int i = 0; i < nieceAndNephews.size(); i++) {
                System.out.println(nieceAndNephews.get(i));
            }

        }

        for (int i = 0; i < personArray.size(); i++) {
            if (name.equals(personArray.get(i).getName())) {
                for (int j = 0; j < personArray.get(i).getChildren().size(); j++) {
                    childrenArray.add(personArray.get(i).getChildren().get(j));
                }
            }
        }

        System.out.println("Children :");
        for (int i = 0; i < childrenArray.size(); i++) {
            System.out.println(childrenArray.get(i));

        }
    }

    // Print out every persons relationships 
    //@param none
    //@return void
    public void PrintOutWholeTree() {
        System.out.println();
        System.out.println(familyName + "'s FAMILY TREE");
        
        for (int i = 0; i < personArray.size(); i++) {
            System.out.println("");
            System.out.println(personArray.get(i).getName());
            searchForRelationships(personArray.get(i).getName());

        }
    }

    //delete a family member for tree and adjust the relationships to elimate this that person from the tree
    //@param person you want to delete from the tree
    //@return void
    public void deleteSomeOne(String deletePerson) {
        for (int i = 0; i < personArray.size(); i++) {
            if (deletePerson.equals(personArray.get(i).getName())) {
                personArray.remove(i);
            }
            if (personArray.get(i).getSpouse() != null) {
                if (deletePerson.equals(personArray.get(i).getSpouse().getName())) {
                    personArray.get(i).setSpouse(null);
                }
            }
            if (personArray.get(i).getParentOne() != null) {
                if (deletePerson.equals(personArray.get(i).getParentOne().getName())) {
                    personArray.get(i).setParentOne(null);
                }
            }
            if (personArray.get(i).getPartentTwo() != null) {
                if (deletePerson.equals(personArray.get(i).getPartentTwo().getName())) {
                    personArray.get(i).setPartentTwo(null);
                }
            }
            for (int j = 0; j < personArray.get(i).getChildren().size(); j++) {
                if (!personArray.get(i).getChildren().isEmpty()) {
                    if (deletePerson.equals(personArray.get(i).getChildren().get(j).getName())) {
                        personArray.get(i).getChildren().remove(j);
                    }
                }
            }
        }

    }

    //change someones info from living to dead
    //@param none
    //@return void
    public void changeToDead(String name, String dateOfDeath) {
        ArrayList<Person> clist = new ArrayList<Person>();
        Person S;
        Person P1;
        Person P2;
        Person deadPerson;

        for (int i = 0; i < personArray.size(); i++) {
            System.out.println("im in");
            if (name.equals(personArray.get(i).getName())) {
                System.out.println("found" + personArray.get(i).getName());
                S = personArray.get(i).getSpouse();
                clist = personArray.get(i).getChildren();
                P1 = personArray.get(i).getParentOne();
                P2 = personArray.get(i).getPartentTwo();

                for (int j = 0; j < clist.size(); j++) {
                    if (clist.get(j).getParentOne() != null) {
                        if (clist.get(j).getParentOne().equals(personArray.get(i))) {
                            clist.get(j).setParentOne(null);
                        } else if (clist.get(j).getPartentTwo() != null) {
                            if (clist.get(j).getPartentTwo().equals(personArray.get(i))) {
                                clist.get(j).setPartentTwo(null);
                            }
                        }
                    }
                }

                S.setSpouse(null);

                if (P1 != null) {
                    int index = P1.getChildren().indexOf(personArray.get(i));
                    P1.getChildren().remove(index);

                }
                if (P2 != null) {
                    int index = P2.getChildren().indexOf(personArray.get(i));
                    P2.getChildren().remove(index);

                }

                deadPerson died = new deadPerson(personArray.get(i).getName(), personArray.get(i).getBirthday(), dateOfDeath);

                died.setParentOne(P1);
                died.setPartentTwo(P2);
                died.setChildren(clist);
                personArray.remove(personArray.get(i));
                personArray.add(died);

                for (int k = 0; k < personArray.size(); k++) {

                    if (name.equals(personArray.get(k).getName())) {
                        deadPerson = personArray.get(k);

                        for (int j = 0; j < clist.size(); j++) {
                            if (clist.get(j).getParentOne() == null) {
                                clist.get(j).setParentOne(deadPerson);
                            } else if (clist.get(j).getPartentTwo() == null) {
                                clist.get(j).setPartentTwo(deadPerson);
                            }
                        }

                        S.setSpouse(deadPerson);
                        if (P1 != null) {
                            P1.getChildren().add(died);
                        }
                        if (P2 != null) {
                            P2.getChildren().add(died);
                        }
                    }
                }
                break;
            }
        }
    }

    //save family tree of a user to a file
    //@param none
    //@return void
    public void printToFile() throws FileNotFoundException, IOException {
        File f = new File(familyName + ".txt");    // file to store users
        PrintWriter pw = new PrintWriter(f);// print writer to write albums

        for (int i = 0; i < personArray.size(); i++) {
            pw.println(personArray.get(i));

        }
        pw.println();

        for (int j = 0; j < personArray.size(); j++) {
            if (personArray.get(j).getChildren() != null) {
                for (int k = 0; k < personArray.get(j).getChildren().size(); k++) {

                    pw.println(personArray.get(j).getName() + ", parentof, " + personArray.get(j).getChildren().get(k).getName());

                }
            }
        }
        int counter = 0;
        for (int j = 0; j < personArray.size(); j++) {

            if (personArray.get(j).getSpouse() != null) {
                if (counter != 0) {
                    pw.println();
                }

                pw.print(personArray.get(j).getName() + ", marriedto, " + personArray.get(j).getSpouse().getName());
                counter++;
            }

        }

        pw.close();

    }
}
